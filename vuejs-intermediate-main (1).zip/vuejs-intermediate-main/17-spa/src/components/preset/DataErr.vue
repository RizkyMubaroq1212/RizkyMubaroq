<template>
  <span class="data-err"><slot /></span>
</template>

<script>
export default {
  name: 'DataErr'
}
</script>
