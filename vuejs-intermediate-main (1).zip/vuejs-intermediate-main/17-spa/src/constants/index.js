export const URL_API = 'https://highlight-code-api.vercel.app/api'
export const OPSI_STRINGIFY = {
  skipEmptyString: true,
  skipNull: true
}
