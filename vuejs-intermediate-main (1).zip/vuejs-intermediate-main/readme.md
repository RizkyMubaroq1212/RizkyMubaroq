# Vuejs Intermediate

> Source code for Vue.js Intermediate PENS 2020 Webinar

## 🌎 Languages

Read this description in another languages:

- [🇮🇩 Indonesian](./readme-id.md)

## Description

- [Slide](https://bit.ly/vuejs-vuex)
- [Source Code](https://github.com/jefrydco/vuejs-intermediate)
<!-- - [Playback Record](https://bit.ly/playback-vuejs) -->
- [Submission Form](http://bit.ly/SubmisiVueHimit)
- [Application Example](https://vuejs-intermediate-vuex.netlify.app/)
