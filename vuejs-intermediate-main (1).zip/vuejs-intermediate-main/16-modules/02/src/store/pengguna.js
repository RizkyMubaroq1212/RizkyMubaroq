function state() {
  return {
    nama: 'Evan You',
    umur: 30
  }
}

export default {
  namespaced: true,
  state
}