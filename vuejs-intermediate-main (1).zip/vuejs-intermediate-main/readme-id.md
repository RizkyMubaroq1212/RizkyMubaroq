# Vuejs Tingkat Menengah

> Kode sumber untuk demo materi Webinar Vue.js Tingkat Menengah PENS 2020

## 🌎 Bahasa

Baca deskripsi ini dalam bahasa lain:

- [🇬🇧 English](./readme.md)

## Deskripsi

- [Salindia (_Slide_)](https://bit.ly/vuejs-vuex)
- [Kode Sumber](https://github.com/jefrydco/vuejs-intermediate)
<!-- - [Rekaman Ulang](https://bit.ly/playback-vuejs) -->
- [Formulir Submisi](http://bit.ly/SubmisiVueHimit)
- [Contoh Aplikasi](https://vuejs-intermediate-vuex.netlify.app/)
