<template>
  <main>
    <!-- TODO: Tulis kode di sini -->
  </main>
</template>

<script>
export default {
  name: 'App'
}
</script>

